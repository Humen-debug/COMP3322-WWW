import React from "react";
import "./App.css";
import $ from "jquery";
import Cookies from "universal-cookie";
const cookies = new Cookies();

class Header extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            loggedIn: cookies.get("userId") ? true : false,
        };
        this.onSignOutClick = this.onSignOutClick.bind(this);
    }

    onSignOutClick() {
        $.ajax({
            url: "http://localhost:3001/signout",
            method: "GET",
            xhrFields: { withCredentials: true },
        }).done(() => {
            cookies.remove("userId");
            this.setState({ loggedIn: false });
        });
    }

    render() {
        return (
            <header>
                <h3>A Shop</h3>
                <div className="search">
                    <div id="search_form">
                        <select
                            onChange={(e) =>
                                this.props.handleCategoryChange(e.target.value)
                            }
                        >
                            <option key="All" value="">
                                All
                            </option>
                            {Array.from(this.props.categories).map(
                                (element) => {
                                    return (
                                        <option key={element} value={element}>
                                            {element}
                                        </option>
                                    );
                                }
                            )}
                        </select>
                        <input
                            type="text"
                            onChange={(e) =>
                                this.props.handleSearchChange(e.target.value)
                            }
                        />
                        <button
                            type="Submit"
                            onClick={() => {
                                this.props.handlePageChange("shop");
                                this.props.showAllProducts();
                            }}
                        >
                            <img
                                className="icon"
                                src="/Search.png"
                                alt="Search"
                            />
                        </button>
                    </div>
                </div>
                {this.state.loggedIn ? (
                    <div
                        className="cart"
                        onClick={() => {
                            this.props.handlePageChange("cart");
                        }}
                    >
                        <p id="user_totalnum">
                            {this.props.userInfo.totalnum} in cart
                            <img className="icon" src="/Cart.png" alt="Cart" />
                        </p>
                    </div>
                ) : null}
                {this.state.loggedIn ? (
                    <p className="signIn">
                        Hello, {this.props.userInfo.username} <br />
                        <a onClick={this.onSignOutClick}>(Sign out)</a>
                    </p>
                ) : (
                    <a className="signIn" onClick={this.props.toggleSignIn}>
                        Sign in
                    </a>
                )}
            </header>
        );
    }
}

function Footer(props) {
    return (
        <footer>
            <a onClick={() => props.handlePageChange("shop")}>{props.label}</a>
        </footer>
    );
}

class SignInPage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            input_username: "",
            input_password: "",
            message: "Sign In",
        };
        this.handleInputChange = this.handleInputChange.bind(this);
        this.isInputFilled = this.isInputFilled.bind(this);
        this.signIn = this.signIn.bind(this);
    }
    handleInputChange(event) {
        const target = event.target;
        const value = target.value;
        const name = target.name;

        this.setState({ [name]: value });
    }
    isInputFilled() {
        var check = true;
        $("#signin_form input").each(function () {
            if ($(this).val() === "") {
                check = false;
            }
        });
        return check;
    }
    signIn() {
        if (this.isInputFilled()) {
            var new_doc = {
                username: $("#input_username").val(),
                password: $("#input_password").val(),
            };

            $.ajax({
                url: "http://localhost:3001/signin",
                method: "POST",
                data: new_doc,
                dataType: "JSON",
                xhrFields: { withCredentials: true },
            })
                .done((res) => {
                    if (res.msg) {
                        this.setState({ message: res.msg });
                    } else {
                        console.log("retrieve sign in:" + res.userId);
                        cookies.set("userId", res.userId);
                        this.setState({ message: "Sign In" });
                        this.props.getSessionInfo();
                        this.props.toggleSignIn();
                    }
                    return;
                })
                .fail((e) => {
                    console.log("FAIL TO LOGIN");
                });
        } else {
            alert("You must enter username and password");
        }
    }
    render() {
        return (
            <React.Fragment>
                <section className="signIn_container">
                    <h1>{this.state.message}</h1>
                    <div id="signin_form">
                        <input
                            type="text"
                            name="input_username"
                            id="input_username"
                            placeholder="Username"
                            value={this.state.input_username}
                            onChange={(e) => this.handleInputChange(e)}
                        />

                        <input
                            type="password"
                            name="input_password"
                            id="input_password"
                            placeholder="Password"
                            value={this.state.input_password}
                            onChange={(e) => this.handleInputChange(e)}
                        />

                        <button onClick={this.signIn}>Sign in</button>
                    </div>
                </section>
            </React.Fragment>
        );
    }
}

class ProductPage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            quantity: 1,
            bought: false,
        };
        this.addToCart = this.addToCart.bind(this);
        this.handleQuantityChange = this.handleQuantityChange.bind(this);
    }

    handleQuantityChange(quantity) {
        this.setState({ quantity: quantity });
    }
    addToCart() {
        var product = {
            productId: this.props.product._id,
            quantity: this.state.quantity,
        };
        $.ajax({
            method: "POST",
            url: "http://localhost:3001/add_to_cart",
            data: product,
            xhrFields: { withCredentials: true },
        }).done((doc) => {
            // console.log(doc);
            if (doc.msg) return;
            this.props.getSessionInfo();
            this.setState({ bought: true });
        });
    }

    render() {
        return (
            <React.Fragment>
                <section className="container">
                    <img src={this.props.product.image} />
                    {this.state.bought ? (
                        <div className="popUpMessage">
                            <p>Added to Cart</p>
                        </div>
                    ) : (
                        <div className="product_container">
                            <div className="description">
                                <h1>{this.props.product.name}</h1>
                                <h3>$ {this.props.product.price}</h3>
                                <p>{this.props.product.manufacturer}</p>
                                <p>{this.props.product.description}</p>
                            </div>
                            <div className="addToCart">
                                <label>
                                    Quantity:{" "}
                                    <input
                                        type="number"
                                        name="quantity"
                                        min={1}
                                        defaultValue={1}
                                        onChange={(e) =>
                                            this.handleQuantityChange(
                                                e.target.value
                                            )
                                        }
                                        onKeyDown={(e) => e.preventDefault()}
                                    />
                                </label>

                                <button
                                    onClick={() =>
                                        cookies.get("userId")
                                            ? this.addToCart()
                                            : this.props.toggleSignIn()
                                    }
                                >
                                    Add to Cart
                                </button>
                            </div>
                        </div>
                    )}
                </section>
                <Footer
                    label={this.state.bought ? "Continue Browsing" : "Go Back"}
                    handlePageChange={this.props.handlePageChange}
                />
            </React.Fragment>
        );
    }
}

class ShopPage extends React.Component {
    constructor(props) {
        super(props);
        this.showProduct = this.showProduct.bind(this);
    }
    showProduct(id) {
        $.ajax({
            url: "http://localhost:3001/load_product/" + id,
            method: "GET",
            xhrFields: { withCredentials: true },
        }).done((docs) => {
            // have error
            if (docs.msg) {
                return;
            }
            // console.log(docs);
            this.props.findProduct(id, docs.manufacturer, docs.description);

            this.props.handlePageChange("product");
        });
    }

    componentDidMount() {
        this.props.getSessionInfo();
        this.props.showAllProducts();
    }

    render() {
        return (
            <React.Fragment>
                <section className="contents">
                    {this.props.productInfo.map((product) => {
                        return (
                            <div
                                className="product"
                                key={product._id}
                                onClick={() => this.showProduct(product._id)}
                            >
                                <img src={product.image} alt={product.name} />
                                <p className="product_name">{product.name}</p>
                                <p className="price">$ {product.price}</p>
                            </div>
                        );
                    })}
                </section>
            </React.Fragment>
        );
    }
}

class CartPage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            cart: [],
            totalPrice: 0,
            totalnum: 0,
            checkout: false,
        };
        this.showProductsInCart = this.showProductsInCart.bind(this);
        this.updateProductInCart = this.updateProductInCart.bind(this);
        this.handleTotalPriceChange = this.handleTotalPriceChange.bind(this);
        this.onCheckOutClick = this.onCheckOutClick.bind(this);
    }
    showProductsInCart() {
        $.ajax({
            url: "http://localhost:3001/load_cart",
            method: "GET",
            xhrFields: { withCredentials: true },
        }).done((res) => {
            var sum = 0;

            res.cart.map(
                (product) => (sum += product.price * product.quantity)
            );
            this.setState({
                cart: res.cart,
                totalPrice: sum,
                totalnum: res.totalnum,
            });
        });
    }

    handleTotalPriceChange(event, price) {
        console.log(
            "old value: %s, new value: %s",
            event.target.defaultValue,
            event.target.value
        );
        if (event.target.defaultValue < event.target.value) {
            this.setState({ totalPrice: this.state.totalPrice + price });
        } else {
            this.setState({ totalPrice: this.state.totalPrice - price });
        }
        event.target.defaultValue = event.target.value;
    }
    updateProductInCart(quantity, id) {
        var json = { quantity: quantity, productId: id };

        if (quantity == 0) {
            $.ajax({
                url: "http://localhost:3001/delete_from_cart/" + id,
                method: "GET",
                xhrFields: { withCredentials: true },
            }).done((doc) => {
                if (doc.msg) {
                    return;
                }
                this.props.getSessionInfo();

                this.setState({
                    cart: this.state.cart.filter(
                        (product) => product._id !== id
                    ),
                    totalnum: doc.totalnum,
                });
            });
        } else {
            $.ajax({
                url: "http://localhost:3001/update_cart",
                method: "POST",
                data: json,
                dataType: "JSON",
                xhrFields: { withCredentials: true },
            }).done((doc) => {
                if (doc.msg) {
                    return;
                }
                this.props.getSessionInfo();
                this.setState({
                    totalnum: doc.totalnum,
                });
            });
        }
    }
    onCheckOutClick() {
        $.ajax({
            url: "http://localhost:3001/checkout",
            method: "GET",
            xhrFields: { withCredentials: true },
        }).done((doc) => {
            // console.log(doc);
            this.setState({ checkout: true });
            this.props.getSessionInfo();
        });
    }

    componentDidMount() {
        this.props.getSessionInfo();
        this.showProductsInCart();
    }

    render() {
        return (
            <React.Fragment>
                {this.state.checkout ? (
                    <section>
                        <div className="popUpMessage">
                            <p>
                                You have successfully placed order for{" "}
                                {this.state.totalnum} item
                                {parseInt(this.state.totalnum) <= 1
                                    ? ""
                                    : "s"}{" "}
                                <br />${this.state.totalPrice} paid
                            </p>
                        </div>
                    </section>
                ) : (
                    <section>
                        <h1>Shopping Cart</h1>
                        {this.state.cart.map((product) => {
                            return (
                                <ul className="productInCart" key={product._id}>
                                    <li className="productImage">
                                        <img src={product.image} />
                                    </li>
                                    <li className="productInfo">
                                        <p className="product_name">
                                            {product.name}
                                        </p>
                                    </li>
                                    <li className="productPrice">
                                        <p>Price: $ {product.price}</p>
                                    </li>

                                    <li>
                                        <label>Quantity </label>
                                        <input
                                            type="number"
                                            min={0}
                                            defaultValue={product.quantity}
                                            onChange={(e) => {
                                                this.updateProductInCart(
                                                    e.target.value,
                                                    product._id
                                                );
                                                this.handleTotalPriceChange(
                                                    e,
                                                    product.price
                                                );
                                            }}
                                            onKeyDown={(e) =>
                                                e.preventDefault()
                                            }
                                        />
                                    </li>
                                </ul>
                            );
                        })}
                    </section>
                )}

                {this.state.checkout ? (
                    <Footer
                        label="Continue Browsing"
                        handlePageChange={this.props.handlePageChange}
                    />
                ) : (
                    <div className="cartBar">
                        <p>
                            Cart subtotal ({this.props.userInfo.totalnum} item
                            {parseInt(this.props.userInfo.totalnum) <= 1
                                ? ""
                                : "s"}
                            ): $ {this.state.totalPrice}
                        </p>
                        <button
                            disabled={this.props.userInfo.totalnum === 0}
                            onClick={this.onCheckOutClick}
                        >
                            Proceed to Check Out
                        </button>
                    </div>
                )}
            </React.Fragment>
        );
    }
}

class MainPage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            page: "shop",
            productInfo: [],
            product: null,
            categories: new Set(),
            currentFilter: "",
            searchString: "",
            userInfo: {},
            isSignInHidden: true,
        };
        this.handlePageChange = this.handlePageChange.bind(this);
        this.handleCategoryChange = this.handleCategoryChange.bind(this);
        this.handleSearchChange = this.handleSearchChange.bind(this);
        this.showAllProducts = this.showAllProducts.bind(this);
        this.getSessionInfo = this.getSessionInfo.bind(this);
        this.renderSwitch = this.renderSwitch.bind(this);

        this.findProduct = this.findProduct.bind(this);
        this.toggleSignIn = this.toggleSignIn.bind(this);
    }

    showAllProducts() {
        var url =
            "http://localhost:3001/load_page?category=" +
            this.state.currentFilter +
            "&searchString=" +
            this.state.searchString;

        $.ajax({
            url: url,
            method: "GET",
            xhrFields: { withCredentials: true },
        }).done((docs) => {
            this.setState({ productInfo: docs });
            docs.forEach((element) => {
                this.setState({
                    categories: this.state.categories.add(element.category),
                });
            });
        });
    }

    getSessionInfo() {
        $.ajax({
            url: "http://localhost:3001/get_session_info",
            method: "GET",
            xhrFields: { withCredentials: true },
        }).done((doc) => {
            if (doc.msg != null) {
                return;
            } else {
                this.setState(
                    {
                        userInfo: {
                            username: doc.username,
                            totalnum: doc.totalnum,
                        },
                    },
                    function () {
                        console.log(
                            "Update User %s with total num %d at Page %s",
                            doc.username,
                            doc.totalnum,
                            this.state.page
                        );
                    }
                );
            }
        });
    }

    toggleSignIn() {
        this.setState({ isSignInHidden: !this.state.isSignInHidden });
    }

    renderSwitch(param) {
        switch (param) {
            case "shop":
                return (
                    <ShopPage
                        handlePageChange={this.handlePageChange}
                        userInfo={this.state.userInfo}
                        showAllProducts={this.showAllProducts}
                        getSessionInfo={this.getSessionInfo}
                        productInfo={this.state.productInfo}
                        findProduct={this.findProduct}
                    />
                );
            case "product":
                return (
                    <ProductPage
                        handlePageChange={this.handlePageChange}
                        userInfo={this.state.userInfo}
                        showAllProducts={this.showAllProducts}
                        getSessionInfo={this.getSessionInfo}
                        toggleSignIn={this.toggleSignIn}
                        product={this.state.product}
                    />
                );
            case "cart":
                return (
                    <CartPage
                        handlePageChange={this.handlePageChange}
                        userInfo={this.state.userInfo}
                        showAllProducts={this.showAllProducts}
                        getSessionInfo={this.getSessionInfo}
                        productInfo={this.state.productInfo}
                    />
                );
            default:
                return <MainPage />;
        }
    }

    findProduct(id, manufacturer, description) {
        // console.log(this.state.productInfo);
        var newProduct =
            id === 0
                ? null
                : this.state.productInfo.find((element) => element._id === id);
        if (newProduct) {
            newProduct.manufacturer = manufacturer;
            newProduct.description = description;
            this.setState({
                product: newProduct,
            });
        }
    }

    handlePageChange(page) {
        this.setState({ page: page });
    }

    handleCategoryChange(category) {
        this.setState({ currentFilter: category }, function () {
            console.log("Change category: %s", this.state.currentFilter);
            this.showAllProducts();
            this.handlePageChange("shop");
        });
    }

    handleSearchChange(product) {
        this.setState({ searchString: product }, function () {
            console.log("Change search: %s", this.state.searchString);
        });
    }

    componentDidMount() {
        this.showAllProducts();
        this.getSessionInfo();
    }

    render() {
        return this.state.isSignInHidden ? (
            <React.Fragment>
                <Header
                    handleCategoryChange={this.handleCategoryChange}
                    handlePageChange={this.handlePageChange}
                    handleSearchChange={this.handleSearchChange}
                    userInfo={this.state.userInfo}
                    categories={this.state.categories}
                    showAllProducts={this.showAllProducts}
                    getSessionInfo={this.getSessionInfo}
                    toggleSignIn={this.toggleSignIn}
                />
                {this.renderSwitch(this.state.page)}
            </React.Fragment>
        ) : (
            <SignInPage
                toggleSignIn={this.toggleSignIn}
                getSessionInfo={this.getSessionInfo}
            />
        );
    }
}

export default MainPage;
